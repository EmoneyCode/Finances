
/**
 * Write a description of class Institutions here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Institutions{
    // instance variables - replace the example below with your own
    public String name;
    Accounts[] account;

    /**
     * Constructor for objects of class Institutions
     */
    public Institutions(String name){
        this.name = name;
        this.account = new Accounts [100];
    }
    
    public Accounts[] getAccounts() {
        return this.account;
    }
}
