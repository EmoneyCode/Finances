
/**
 * Write a description of class Finances here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Finances{
    

    private Institutions[] institutions;

    public Finances() {
        this.institutions = new Institutions[100];
    }

    public void addInstitution(String name) {
        if (!instituteExists(name)) {
            for (int i = 0; i < institutions.length; i++) {
                if (institutions[i] == null) {
                    institutions[i] = new Institutions(name);
                    return;
                }
            }
        } else {
            System.out.println("Cannot add " + name + ", already exists");
        }
    }

    public void removeInstitution(String name) {
        int index = findInstitutionIndex(name);
        if (index != -1) {
            institutions[index] = null;
        } else {
            System.out.println("Institution does not exist: " + name);
        }
    }

    public boolean instituteExists(String name) {
        return findInstitutionIndex(name) != -1;
    }

    private int findInstitutionIndex(String name) {
        for (int i = 0; i < institutions.length; i++) {
            if (institutions[i] != null && name.equals(institutions[i].name)) {
                return i;
            }
        }
        return -1;
    }

    public void addAccount(String institutionName, String accountType) {
        int institutionIndex = findInstitutionIndex(institutionName);
        if (institutionIndex != -1) {
            if (!accountExists(institutionName, accountType)) {
                for (int i = 0; i < institutions[institutionIndex].getAccounts().length; i++) {
                    if (institutions[institutionIndex].getAccounts()[i] == null) {
                        institutions[institutionIndex].getAccounts()[i] = new Accounts(accountType);
                        return;
                    }
                }
            } else {
                System.out.print("Can't add ");
                if (accountType.equals("S")){
                    System.out.print("savings,");
                }
                if (accountType.equals("C")){
                    System.out.print("checking,");
                }
                System.out.println(" already exists.");
            }
        } else {
            System.out.println("Institution "+ institutionName + " does not exist");
        }
    }

    public boolean accountExists(String name, String accountType) {
        Institutions institution = findInstitutionByName(name);
        for (Accounts account : institution.account) {
            if (account != null && accountType.equals(account.accountType)) {
                return true;
            }
        }
        return false;
    }
    private Institutions findInstitutionByName(String name) {
    for (Institutions inst : institutions) {
        if (inst != null && name.equals(inst.name)) {
            return inst;
        }
    }
    return null;
    }

    public void deposit(String name, String accountType, double amount) {
        int institutionIndex = findInstitutionIndex(name);
        if (institutionIndex != -1) {
            Accounts account = findAccount(institutions[institutionIndex], accountType);
            if (account != null) {
                account.amount += amount;
            } else {
                System.out.println("Account does not exist: " + accountType);
            }
        } else {
            System.out.println("Institution does not exist: " + name);
        }
    }

    public void withdraw(String name, String accountType, double amount) {
        int institutionIndex = findInstitutionIndex(name);
        if (institutionIndex != -1) {
            Accounts account = findAccount(institutions[institutionIndex], accountType);
            if (account != null) {
                if (account.amount >= amount) {
                    account.amount -= amount;
                } else {
                    System.out.println("Insufficient funds for withdrawal: " + amount);
                }
            } else {
                System.out.println("Account does not exist: " + accountType);
            }
        } else {
            System.out.println("Institution does not exist: " + name);
        }
    }

    public void setRate(String name, String accountType, double rate) {
        int institutionIndex = findInstitutionIndex(name);
        if (institutionIndex != -1) {
            Accounts account = findAccount(institutions[institutionIndex], accountType);
            if (account != null) {
                if (rate >= 0) {
                    account.rate = rate;
                } else {
                    System.out.println("Invalid interest rate: " + rate);
                }
            } else {
                System.out.println("Account does not exist:");
            }
        }
    }
    
    public void calculateInterest() {
        for (Institutions institution : institutions) {
            if (institution != null) {
                for (Accounts account : institution.getAccounts()) {
                    if (account != null) {
                        double interest = account.amount * (account.rate / 100.0);
                        account.amount += interest;
                    }
                }
            }
        }
    }

    public void showBalances() {
        for (Institutions institution : institutions) {
            if (institution != null) {
                System.out.println("Institution: " + institution.name);
                for (Accounts account : institution.getAccounts()) {
                    if (account != null) {
                        if (account.accountType.equals("S")){
                            System.out.print("Savings ");
                        }
                        if (account.accountType.equals("C")){
                            System.out.print("Checking ");
                        }
                        System.out.printf(" balance: $%.2f\n", account.amount);
                    }
                }
                System.out.println();
            }
        }
    }
    
    private Accounts findAccount(Institutions institution, String accountType) {
        for (Accounts account : institution.account) {
            if (account != null && accountType.equals(account.accountType)) {
                return account;
            }
        }
        return null;
    }
}
