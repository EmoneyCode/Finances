
/**
 * Write a description of class Institutions here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Accounts
{
    // instance variables - replace the example below with your own
    String accountType;
    double amount;
    double rate;

    /**
     * Constructor for objects of class Institutions
     */
    public Accounts(String accountType){
        // initialise instance variables
        this.accountType = accountType;
    }
    

}
