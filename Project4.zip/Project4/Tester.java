import java.util.Scanner;
/**
  This Tester class has no comments in it for a very specific reason. Reading code that is not commented is difficult, 
  even if the variables are named perfectly. If you do not understand what a particular piece of code is doing, 
  ask me and I will clarify.
**/


public class Tester{
	
	public static void displayMenu(){
        System.out.println("==================================");
		System.out.println("1. Add a financial institution.");
		System.out.println("2. Remove a financial institution.");
		System.out.println("3. Add an account.");
		System.out.println("4. Make a deposit.");
		System.out.println("5. Make a withdrawal.");
		System.out.println("6. Set interest rate.");
		System.out.println("7. Calculate interest.");
		System.out.println("8. Show all balances.");
		System.out.println("9. Quit.");
        System.out.print("Enter a choice: ");
	}

	public static void main(String[] args){		
		Finances finances = new Finances();
		Scanner input = new Scanner(System.in);
		int choice = -1;
		do{
			displayMenu();
			choice = input.nextInt();
			String name;
			String accountType;
			double amount;
			switch(choice){
				case 1: 
					System.out.print("Add financial institution: ");
					name = input.next();
					finances.addInstitution(name); 
					break;
				case 2: 
					System.out.print("Remove financial institution: ");
					name = input.next();
					finances.removeInstitution(name); 
					break;
				case 3: 
					System.out.print("Add account to which financial institution: ");
					name = input.next();
                    if(finances.instituteExists(name)){
                        System.out.print("(C)hecking or (S)avings: ");
                        accountType = input.next();
                        finances.addAccount(name, accountType); 
                    } else{
                        System.out.println("Institution "+name+" does not exist.");
                    }
					break;
				case 4: 					 
					System.out.print("Deposit to which financial institution: ");
					name = input.next();
                    if(finances.instituteExists(name)){
                        System.out.print("(C)hecking or (S)avings: ");
                        accountType = input.next();
                        if(finances.accountExists(name, accountType)){
                            System.out.print("Amount to deposit: ");
                            amount = input.nextDouble();
                            finances.deposit(name, accountType, amount); 
                        } else{
                            System.out.println("Account "+ accountType+" at institution "+name+" does not exist.");
                        }
                    } else{
                        System.out.println("Institution "+name+" does not exist.");
                    }
					break;
				case 5:
					System.out.print("Withdraw from which financial institution: ");
					name = input.next();
					if(finances.instituteExists(name)){
                        System.out.print("(C)hecking or (S)avings: ");
                        accountType = input.next();
                        if(finances.accountExists(name, accountType)){
                            System.out.print("Amount to withdraw: ");
                            amount = input.nextDouble();
                            finances.withdraw(name, accountType, amount); 
                        } else{
                            System.out.println("Account "+ accountType+" at institution "+name+" does not exist.");
                        }
                    } else{
                        System.out.println("Institution "+name+" does not exist.");
                    } 
					break;
				case 6: 
					System.out.print("Set rate for which financial institution: ");
					name = input.next();
                    if(finances.instituteExists(name)){
                        System.out.print("(C)hecking or (S)avings: ");
                        accountType = input.next();
                        if(finances.accountExists(name, accountType)){
                            System.out.print("Interest rate (%): ");
                            double rate = input.nextDouble();
                            finances.setRate(name, accountType, rate); 
                        } else{
                            System.out.println("Account "+ accountType+" at institution "+name+" does not exist.");
                        }
                    } else{
                        System.out.println("Institution "+name+" does not exist.");
                    } 
					break;
				case 7: 
					finances.calculateInterest(); 
					break;
				case 8:
					finances.showBalances();
					break;
				case 9: break;
				default: System.out.println("Invalid choice.");					
			}
		} while(choice!=9);
	}
}
